import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Search, CheckCircle, XCircle, Eye, Award, Users, MapPin } from 'lucide-react';

const ngoData = [
  { id: 'NGO-101', name: 'Indian Red Cross Society', region: 'Pan India', status: 'Approved', campsOrganized: 45, donorsReached: 12500, verificationDocs: true },
  { id: 'NGO-102', name: 'Rotary Blood Bank', region: 'Mumbai', status: 'Pending Approval', campsOrganized: 0, donorsReached: 0, verificationDocs: false },
  { id: 'NGO-103', name: 'Lions Club International', region: 'Delhi', status: 'Approved', campsOrganized: 32, donorsReached: 8900, verificationDocs: true },
  { id: 'NGO-104', name: 'Blood Connect Foundation', region: 'Bangalore', status: 'Approved', campsOrganized: 28, donorsReached: 7200, verificationDocs: true },
];

const campProposals = [
  { id: 'CAMP-501', organizer: 'Indian Red Cross Society', location: 'Central Park, Delhi', date: '2026-01-15', expectedDonors: 500, status: 'Pending Approval' },
  { id: 'CAMP-502', organizer: 'Lions Club International', location: 'Tech Park, Bangalore', date: '2026-01-20', expectedDonors: 300, status: 'Approved' },
  { id: 'CAMP-503', organizer: 'Blood Connect Foundation', location: 'University Campus, Pune', date: '2026-01-18', expectedDonors: 450, status: 'Pending Review' },
];

const certificateData = [
  { donorId: 'DN-5601', donorName: 'Vikram Singh', campId: 'CAMP-498', date: '2026-01-05', status: 'Issued' },
  { donorId: 'DN-5603', donorName: 'Arjun Mehta', campId: 'CAMP-499', date: '2026-01-06', status: 'Issued' },
  { donorId: 'DN-5608', donorName: 'Kavita Desai', campId: 'CAMP-502', date: '2026-01-07', status: 'Pending' },
];

export function CampsNGOs() {
  return (
    <div className="space-y-6 mt-16">
      {/* Page Header */}
      <div>
        <h2 className="font-semibold text-gray-900 mb-1">Donation Camp & NGO Management</h2>
        <p className="text-sm text-gray-500">Manage NGO partnerships and blood donation camps</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 border-l-4 border-l-[#3B82F6]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#EFF6FF] flex items-center justify-center">
              <Users className="size-5 text-[#3B82F6]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">28</p>
              <p className="text-sm text-gray-500">Active NGOs</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#10B981]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#F0FDF4] flex items-center justify-center">
              <MapPin className="size-5 text-[#10B981]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">145</p>
              <p className="text-sm text-gray-500">Camps This Month</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#8B5CF6]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#F5F3FF] flex items-center justify-center">
              <Users className="size-5 text-[#8B5CF6]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">34,567</p>
              <p className="text-sm text-gray-500">Donors Reached</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#F97316]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#FFF7ED] flex items-center justify-center">
              <Award className="size-5 text-[#F97316]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">5</p>
              <p className="text-sm text-gray-500">Pending Approvals</p>
            </div>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="ngos" className="space-y-4">
        <TabsList className="bg-gray-100">
          <TabsTrigger value="ngos">NGO Registry</TabsTrigger>
          <TabsTrigger value="camps">Camp Proposals</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
        </TabsList>

        {/* NGO Registry Tab */}
        <TabsContent value="ngos" className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                <Input placeholder="Search NGOs..." className="pl-10" />
              </div>
              <Button className="bg-[#3B82F6] hover:bg-[#2563EB]">Register New NGO</Button>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>NGO ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Camps Organized</TableHead>
                    <TableHead>Donors Reached</TableHead>
                    <TableHead>Verification</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ngoData.map((ngo) => (
                    <TableRow key={ngo.id}>
                      <TableCell className="font-medium font-mono text-sm">{ngo.id}</TableCell>
                      <TableCell className="font-medium">{ngo.name}</TableCell>
                      <TableCell>{ngo.region}</TableCell>
                      <TableCell className="text-center">{ngo.campsOrganized}</TableCell>
                      <TableCell className="text-center">{ngo.donorsReached.toLocaleString()}</TableCell>
                      <TableCell>
                        {ngo.verificationDocs ? (
                          <Badge variant="outline" className="bg-[#F0FDF4] text-[#10B981] border-[#10B981]">
                            <CheckCircle className="size-3 mr-1" />
                            Verified
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-[#FFF7ED] text-[#F97316] border-[#F97316]">
                            Pending
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            ngo.status === 'Approved'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          }
                        >
                          {ngo.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {ngo.status === 'Pending Approval' && (
                            <>
                              <Button variant="ghost" size="sm" className="text-[#10B981]" title="Approve">
                                <CheckCircle className="size-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-[#EF4444]" title="Reject">
                                <XCircle className="size-4" />
                              </Button>
                            </>
                          )}
                          <Button variant="ghost" size="sm">
                            <Eye className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Camp Proposals Tab */}
        <TabsContent value="camps" className="space-y-4">
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Camp Proposals</h3>
                <p className="text-sm text-gray-500">Review and approve upcoming donation camps</p>
              </div>
              <Button variant="outline">Filter by Date</Button>
            </div>

            <div className="space-y-3">
              {campProposals.map((camp) => (
                <Card key={camp.id} className="p-4 border-l-4 border-l-[#3B82F6]">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-medium font-mono text-sm">{camp.id}</span>
                        <Badge
                          variant="outline"
                          className={
                            camp.status === 'Approved'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : camp.status === 'Pending Approval'
                              ? 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                              : 'bg-[#FFFBEB] text-yellow-600 border-yellow-500'
                          }
                        >
                          {camp.status}
                        </Badge>
                      </div>
                      <h4 className="font-medium mb-1">{camp.organizer}</h4>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <MapPin className="size-4" />
                          {camp.location}
                        </span>
                        <span>📅 {camp.date}</span>
                        <span>👥 Expected: {camp.expectedDonors} donors</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {camp.status !== 'Approved' && (
                        <>
                          <Button variant="outline" size="sm" className="text-[#EF4444]">
                            <XCircle className="size-4 mr-1" />
                            Reject
                          </Button>
                          <Button size="sm" className="bg-[#10B981] hover:bg-[#059669]">
                            <CheckCircle className="size-4 mr-1" />
                            Approve
                          </Button>
                        </>
                      )}
                      <Button variant="ghost" size="sm">
                        <Eye className="size-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Certificates Tab */}
        <TabsContent value="certificates" className="space-y-4">
          <Card className="p-6">
            <div className="mb-4">
              <h3 className="font-semibold text-gray-900 mb-1">Certificate Issuance Status</h3>
              <p className="text-sm text-gray-500">Track donor appreciation certificates</p>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Donor ID</TableHead>
                    <TableHead>Donor Name</TableHead>
                    <TableHead>Camp ID</TableHead>
                    <TableHead>Donation Date</TableHead>
                    <TableHead>Certificate Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {certificateData.map((cert, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-medium font-mono text-sm">{cert.donorId}</TableCell>
                      <TableCell>{cert.donorName}</TableCell>
                      <TableCell className="font-mono text-sm">{cert.campId}</TableCell>
                      <TableCell>{cert.date}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            cert.status === 'Issued'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          }
                        >
                          {cert.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {cert.status === 'Pending' && (
                            <Button size="sm" className="bg-[#3B82F6] hover:bg-[#2563EB]">
                              Issue Certificate
                            </Button>
                          )}
                          {cert.status === 'Issued' && (
                            <Button size="sm" variant="outline">
                              View Certificate
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Top Performing NGOs</h3>
              <div className="space-y-3">
                {ngoData.slice(0, 3).map((ngo, idx) => (
                  <div key={ngo.id} className="flex items-center gap-3">
                    <div className="size-8 rounded-full bg-[#EFF6FF] flex items-center justify-center font-semibold text-[#3B82F6]">
                      {idx + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{ngo.name}</p>
                      <p className="text-xs text-gray-500">{ngo.donorsReached.toLocaleString()} donors reached</p>
                    </div>
                    <Award className="size-5 text-[#F97316]" />
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Participation Metrics</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Camp Attendance Rate</span>
                    <span className="font-semibold">87%</span>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Conversion to Donation</span>
                    <span className="font-semibold text-[#10B981]">92%</span>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Repeat Donors</span>
                    <span className="font-semibold">45%</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
