import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { BarChart3, TrendingUp, Download, Users, Droplet, TruckIcon, Heart } from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

const weeklyPerformanceData = [
  { week: 'Week 1', requests: 456, fulfilled: 423, donors: 234 },
  { week: 'Week 2', week: 532, fulfilled: 498, donors: 278 },
  { week: 'Week 3', requests: 489, fulfilled: 467, donors: 256 },
  { week: 'Week 4', requests: 612, fulfilled: 589, donors: 312 },
];

const bloodUsageTrends = [
  { month: 'Aug', 'A+': 1234, 'O+': 2156, 'B+': 987, 'AB+': 456 },
  { month: 'Sep', 'A+': 1456, 'O+': 2341, 'B+': 1123, 'AB+': 523 },
  { month: 'Oct', 'A+': 1323, 'O+': 2234, 'B+': 1045, 'AB+': 498 },
  { month: 'Nov', 'A+': 1567, 'O+': 2456, 'B+': 1234, 'AB+': 589 },
  { month: 'Dec', 'A+': 1489, 'O+': 2389, 'B+': 1178, 'AB+': 534 },
  { month: 'Jan', 'A+': 1623, 'O+': 2567, 'B+': 1312, 'AB+': 612 },
];

const donorGrowthData = [
  { region: 'North', donors: 8934, growth: 12.5 },
  { region: 'South', donors: 12456, growth: 18.3 },
  { region: 'East', donors: 6789, growth: 9.7 },
  { region: 'West', donors: 10234, growth: 15.2 },
  { region: 'Central', donors: 7823, growth: 11.8 },
];

const riderPerformanceData = [
  { rider: 'Suresh K.', deliveries: 234, avgTime: '28 min', rating: 4.8 },
  { rider: 'Mohammed A.', deliveries: 189, avgTime: '32 min', rating: 4.6 },
  { rider: 'Ravi S.', deliveries: 156, avgTime: '26 min', rating: 4.9 },
  { rider: 'Deepak Y.', deliveries: 142, avgTime: '35 min', rating: 4.5 },
];

export function AnalyticsReports() {
  return (
    <div className="space-y-6 mt-16">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-gray-900 mb-1">Analytics & Reporting</h2>
          <p className="text-sm text-gray-500">Comprehensive insights and performance metrics</p>
        </div>
        <div className="flex gap-3">
          <Select defaultValue="last-30">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last-7">Last 7 Days</SelectItem>
              <SelectItem value="last-30">Last 30 Days</SelectItem>
              <SelectItem value="last-90">Last 90 Days</SelectItem>
              <SelectItem value="ytd">Year to Date</SelectItem>
            </SelectContent>
          </Select>
          <Button className="gap-2 bg-[#3B82F6] hover:bg-[#2563EB]">
            <Download className="size-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 border-l-4 border-l-[#10B981]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#F0FDF4] flex items-center justify-center">
              <Heart className="size-5 text-[#10B981]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">12,453</p>
              <p className="text-sm text-gray-500">Lives Saved (MTD)</p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <TrendingUp className="size-4 text-[#10B981]" />
            <span className="text-sm text-[#10B981] font-medium">+18.2%</span>
            <span className="text-xs text-gray-500">vs last month</span>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#3B82F6]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#EFF6FF] flex items-center justify-center">
              <Droplet className="size-5 text-[#3B82F6]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">96.4%</p>
              <p className="text-sm text-gray-500">Request Fulfillment</p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <TrendingUp className="size-4 text-[#10B981]" />
            <span className="text-sm text-[#10B981] font-medium">+2.1%</span>
            <span className="text-xs text-gray-500">vs last month</span>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#8B5CF6]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#F5F3FF] flex items-center justify-center">
              <Users className="size-5 text-[#8B5CF6]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">1,080</p>
              <p className="text-sm text-gray-500">New Donors (MTD)</p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <TrendingUp className="size-4 text-[#10B981]" />
            <span className="text-sm text-[#10B981] font-medium">+15.3%</span>
            <span className="text-xs text-gray-500">vs last month</span>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#F97316]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#FFF7ED] flex items-center justify-center">
              <TruckIcon className="size-5 text-[#F97316]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">29 min</p>
              <p className="text-sm text-gray-500">Avg. Delivery Time</p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <TrendingUp className="size-4 text-[#10B981]" />
            <span className="text-sm text-[#10B981] font-medium">-3 min</span>
            <span className="text-xs text-gray-500">improved</span>
          </div>
        </Card>
      </div>

      {/* Weekly Performance Chart */}
      <Card className="p-6">
        <div className="mb-4">
          <h3 className="font-semibold text-gray-900 mb-1">Weekly Performance Overview</h3>
          <p className="text-sm text-gray-500">Requests, fulfillment, and donor participation trends</p>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={weeklyPerformanceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="week" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip />
            <Legend />
            <Bar dataKey="requests" fill="#3B82F6" radius={[8, 8, 0, 0]} name="Total Requests" />
            <Bar dataKey="fulfilled" fill="#10B981" radius={[8, 8, 0, 0]} name="Fulfilled" />
            <Bar dataKey="donors" fill="#8B5CF6" radius={[8, 8, 0, 0]} name="Active Donors" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Blood Usage Trends */}
      <Card className="p-6">
        <div className="mb-4">
          <h3 className="font-semibold text-gray-900 mb-1">Blood Usage Trends by Type</h3>
          <p className="text-sm text-gray-500">Monthly consumption patterns for major blood groups</p>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={bloodUsageTrends}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="month" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="O+" stackId="1" stroke="#EF4444" fill="#FEF2F2" />
            <Area type="monotone" dataKey="A+" stackId="1" stroke="#3B82F6" fill="#EFF6FF" />
            <Area type="monotone" dataKey="B+" stackId="1" stroke="#10B981" fill="#F0FDF4" />
            <Area type="monotone" dataKey="AB+" stackId="1" stroke="#8B5CF6" fill="#F5F3FF" />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      {/* Donor Growth by Region */}
      <Card className="p-6">
        <div className="mb-4">
          <h3 className="font-semibold text-gray-900 mb-1">Donor Growth by Region</h3>
          <p className="text-sm text-gray-500">Regional donor acquisition and growth rates</p>
        </div>
        <div className="space-y-4">
          {donorGrowthData.map((region, idx) => (
            <div key={idx} className="flex items-center gap-4">
              <div className="w-32">
                <p className="font-medium">{region.region}</p>
                <p className="text-sm text-gray-500">{region.donors.toLocaleString()} donors</p>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-100 rounded-full h-3">
                    <div
                      className="bg-[#3B82F6] h-3 rounded-full"
                      style={{ width: `${(region.donors / 12456) * 100}%` }}
                    />
                  </div>
                  <Badge
                    variant="outline"
                    className="bg-[#F0FDF4] text-[#10B981] border-[#10B981] whitespace-nowrap"
                  >
                    +{region.growth}%
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Rider Performance & Emergency Success Rate */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rider Performance */}
        <Card className="p-6">
          <div className="mb-4">
            <h3 className="font-semibold text-gray-900 mb-1">Top Performing Riders</h3>
            <p className="text-sm text-gray-500">Delivery performance metrics</p>
          </div>
          <div className="space-y-3">
            {riderPerformanceData.map((rider, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-full bg-[#EFF6FF] flex items-center justify-center font-semibold text-[#3B82F6]">
                    {idx + 1}
                  </div>
                  <div>
                    <p className="font-medium">{rider.rider}</p>
                    <p className="text-sm text-gray-500">{rider.deliveries} deliveries</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">{rider.avgTime}</p>
                  <div className="flex items-center gap-1">
                    <span className="text-sm text-[#F97316]">★</span>
                    <span className="text-sm font-medium">{rider.rating}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Emergency Success Rate */}
        <Card className="p-6">
          <div className="mb-4">
            <h3 className="font-semibold text-gray-900 mb-1">Emergency Request Success Rate</h3>
            <p className="text-sm text-gray-500">Critical request fulfillment analytics</p>
          </div>
          <div className="space-y-4">
            <div className="text-center p-6">
              <div className="size-32 mx-auto rounded-full border-8 border-[#10B981] flex items-center justify-center mb-4">
                <div>
                  <p className="text-4xl font-semibold text-gray-900">97.8%</p>
                  <p className="text-sm text-gray-500">Success Rate</p>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                Critical emergency requests are fulfilled within target time 97.8% of the time
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <p className="text-2xl font-semibold text-gray-900 mb-1">18 min</p>
                <p className="text-sm text-gray-600">Avg. Response Time</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <p className="text-2xl font-semibold text-gray-900 mb-1">892</p>
                <p className="text-sm text-gray-600">Critical Requests (MTD)</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Lives Saved Estimation */}
      <Card className="p-6 bg-gradient-to-r from-[#EFF6FF] to-[#F0FDF4] border-[#3B82F6]">
        <div className="flex items-center gap-4">
          <div className="size-16 rounded-full bg-white flex items-center justify-center">
            <Heart className="size-8 text-[#EF4444]" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1">Lives Saved Estimation</h3>
            <p className="text-sm text-gray-600 mb-3">
              Based on successful blood transfusions and emergency interventions
            </p>
            <div className="flex items-center gap-6">
              <div>
                <p className="text-3xl font-semibold text-gray-900">12,453</p>
                <p className="text-sm text-gray-600">This Month</p>
              </div>
              <div>
                <p className="text-3xl font-semibold text-gray-900">98,234</p>
                <p className="text-sm text-gray-600">This Year</p>
              </div>
              <div>
                <p className="text-3xl font-semibold text-gray-900">456K+</p>
                <p className="text-sm text-gray-600">All Time</p>
              </div>
            </div>
          </div>
          <Button className="bg-[#10B981] hover:bg-[#059669]">
            <Download className="size-4 mr-2" />
            Download Impact Report
          </Button>
        </div>
      </Card>
    </div>
  );
}
