import { Menu, LogOut, Bell, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';

interface HeaderProps {
  onMenuClick: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="h-16 bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-50">
      <div className="h-full px-6 flex items-center justify-between">
        {/* Left: Menu + Logo */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="lg:hidden"
          >
            <Menu className="size-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-[#EF4444] flex items-center justify-center">
              <div className="size-5 text-white font-bold">H</div>
            </div>
            <span className="font-semibold text-gray-900">HAEMOLINK</span>
            <Badge variant="outline" className="ml-2 bg-[#F5F3FF] text-[#8B5CF6] border-[#8B5CF6]">
              Super Admin
            </Badge>
          </div>
        </div>

        {/* Center: Page Title */}
        <div className="hidden md:block">
          <h1 className="font-semibold text-gray-900">Central Control Portal</h1>
        </div>

        {/* Right: Notifications + Avatar */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="size-5" />
            <span className="absolute -top-1 -right-1 size-4 bg-[#EF4444] text-white text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </Button>
          <Button variant="ghost" size="sm">
            <Settings className="size-5" />
          </Button>
          <div className="h-8 w-px bg-gray-200" />
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="bg-[#3B82F6] text-white">SA</AvatarFallback>
            </Avatar>
            <div className="hidden lg:block">
              <p className="text-sm font-medium text-gray-900">Super Admin</p>
              <p className="text-xs text-gray-500">admin@haemolink.gov</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-[#EF4444]">
            <LogOut className="size-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
