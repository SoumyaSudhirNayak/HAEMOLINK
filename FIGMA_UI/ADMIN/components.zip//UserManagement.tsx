import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import {
  Search,
  Filter,
  Eye,
  CheckCircle,
  XCircle,
  AlertCircle,
  FileText,
  Download,
  UserCheck,
  Ban,
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

// Mock data
const patientsData = [
  { id: 'PT-2401', name: 'Rajesh Kumar', bloodGroup: 'A+', city: 'Delhi', requestsCount: 3, lastTransfusion: '2025-12-15', status: 'Active', verified: true },
  { id: 'PT-2402', name: 'Priya Sharma', bloodGroup: 'O-', city: 'Mumbai', requestsCount: 1, lastTransfusion: '2026-01-03', status: 'Active', verified: true },
  { id: 'PT-2403', name: 'Amit Patel', bloodGroup: 'B+', city: 'Ahmedabad', requestsCount: 5, lastTransfusion: '2025-11-28', status: 'Active', verified: false },
  { id: 'PT-2404', name: 'Sneha Reddy', bloodGroup: 'AB+', city: 'Hyderabad', requestsCount: 2, lastTransfusion: '2025-12-20', status: 'Suspended', verified: true },
];

const donorsData = [
  { id: 'DN-5601', name: 'Vikram Singh', bloodGroup: 'O+', donationCount: 12, eligibility: 'Eligible', lastDonation: '2025-11-10', location: 'Bangalore', fraudRisk: false },
  { id: 'DN-5602', name: 'Kavita Desai', bloodGroup: 'A-', donationCount: 8, eligibility: 'Pending Review', lastDonation: '2025-12-01', location: 'Pune', fraudRisk: false },
  { id: 'DN-5603', name: 'Arjun Mehta', bloodGroup: 'B-', donationCount: 15, eligibility: 'Eligible', lastDonation: '2025-10-25', location: 'Delhi', fraudRisk: false },
  { id: 'DN-5604', name: 'Rahul Verma', bloodGroup: 'O+', donationCount: 2, eligibility: 'Not Eligible', lastDonation: '2026-01-05', location: 'Chennai', fraudRisk: true },
];

const ridersData = [
  { id: 'RD-3401', name: 'Suresh Kumar', region: 'North Delhi', deliveries: 234, compliance: 'Verified', status: 'Approved', documentsVerified: true },
  { id: 'RD-3402', name: 'Mohammed Ali', region: 'South Mumbai', deliveries: 0, compliance: 'Pending', status: 'Pending Approval', documentsVerified: false },
  { id: 'RD-3403', name: 'Ravi Shankar', region: 'East Kolkata', deliveries: 189, compliance: 'Verified', status: 'Approved', documentsVerified: true },
  { id: 'RD-3404', name: 'Deepak Yadav', region: 'West Bangalore', deliveries: 156, compliance: 'Incomplete', status: 'Pending Review', documentsVerified: false },
];

const hospitalsData = [
  { id: 'HS-7801', name: 'AIIMS Delhi', license: 'MH/DL/2024/1001', inventoryConnected: true, verification: 'Verified', documentsVerified: true },
  { id: 'HS-7802', name: 'Lilavati Hospital', license: 'MH/MH/2024/2034', inventoryConnected: true, verification: 'Verified', documentsVerified: true },
  { id: 'HS-7803', name: 'City Care Hospital', license: 'MH/KA/2024/5067', inventoryConnected: false, verification: 'Pending', documentsVerified: false },
  { id: 'HS-7804', name: 'Apollo Hospitals', license: 'MH/TN/2024/3421', inventoryConnected: true, verification: 'Verified', documentsVerified: true },
];

export function UserManagement() {
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [verificationModalOpen, setVerificationModalOpen] = useState(false);

  return (
    <div className="space-y-6 mt-16">
      {/* Page Header */}
      <div>
        <h2 className="font-semibold text-gray-900 mb-1">User Management</h2>
        <p className="text-sm text-gray-500">Manage patients, donors, riders, and hospital registrations</p>
      </div>

      {/* Tabbed Interface */}
      <Tabs defaultValue="patients" className="space-y-4">
        <TabsList className="bg-gray-100">
          <TabsTrigger value="patients">Patients</TabsTrigger>
          <TabsTrigger value="donors">Donors</TabsTrigger>
          <TabsTrigger value="riders">Riders</TabsTrigger>
          <TabsTrigger value="hospitals">Hospitals / Blood Banks</TabsTrigger>
        </TabsList>

        {/* Patients Tab */}
        <TabsContent value="patients" className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                <Input placeholder="Search patients..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Blood Group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Blood Groups</SelectItem>
                  <SelectItem value="A+">A+</SelectItem>
                  <SelectItem value="O-">O-</SelectItem>
                  <SelectItem value="B+">B+</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2">
                <Filter className="size-4" />
                Filters
              </Button>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patient ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Blood Group</TableHead>
                    <TableHead>City</TableHead>
                    <TableHead>Requests</TableHead>
                    <TableHead>Last Transfusion</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {patientsData.map((patient) => (
                    <TableRow key={patient.id}>
                      <TableCell className="font-medium">{patient.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {patient.name}
                          {patient.verified && (
                            <CheckCircle className="size-4 text-[#10B981]" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]">
                          {patient.bloodGroup}
                        </Badge>
                      </TableCell>
                      <TableCell>{patient.city}</TableCell>
                      <TableCell>{patient.requestsCount}</TableCell>
                      <TableCell className="text-sm text-gray-500">{patient.lastTransfusion}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            patient.status === 'Active'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : 'bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]'
                          }
                        >
                          {patient.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Eye className="size-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Donors Tab */}
        <TabsContent value="donors" className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                <Input placeholder="Search donors..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Eligibility" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="eligible">Eligible</SelectItem>
                  <SelectItem value="pending">Pending Review</SelectItem>
                  <SelectItem value="not-eligible">Not Eligible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Donor ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Blood Group</TableHead>
                    <TableHead>Donations</TableHead>
                    <TableHead>Eligibility</TableHead>
                    <TableHead>Last Donation</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {donorsData.map((donor) => (
                    <TableRow key={donor.id}>
                      <TableCell className="font-medium">{donor.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {donor.name}
                          {donor.fraudRisk && (
                            <AlertCircle className="size-4 text-[#EF4444]" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]">
                          {donor.bloodGroup}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{donor.donationCount}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            donor.eligibility === 'Eligible'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : donor.eligibility === 'Pending Review'
                              ? 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                              : 'bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]'
                          }
                        >
                          {donor.eligibility}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">{donor.lastDonation}</TableCell>
                      <TableCell>{donor.location}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" title="Suspend">
                            <Ban className="size-4" />
                          </Button>
                          <Button variant="ghost" size="sm" title="View Details">
                            <Eye className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Riders Tab */}
        <TabsContent value="riders" className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                <Input placeholder="Search riders..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rider ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Deliveries</TableHead>
                    <TableHead>Compliance</TableHead>
                    <TableHead>Documents</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ridersData.map((rider) => (
                    <TableRow key={rider.id}>
                      <TableCell className="font-medium">{rider.id}</TableCell>
                      <TableCell>{rider.name}</TableCell>
                      <TableCell>{rider.region}</TableCell>
                      <TableCell className="font-medium">{rider.deliveries}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            rider.compliance === 'Verified'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : rider.compliance === 'Pending'
                              ? 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                              : 'bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]'
                          }
                        >
                          {rider.compliance}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {rider.documentsVerified ? (
                          <Badge variant="outline" className="bg-[#F0FDF4] text-[#10B981] border-[#10B981]">
                            <CheckCircle className="size-3 mr-1" />
                            Verified
                          </Badge>
                        ) : (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="gap-2 text-[#F97316] border-[#F97316]"
                                onClick={() => setSelectedUser(rider)}
                              >
                                <FileText className="size-4" />
                                Review
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl">
                              <DialogHeader>
                                <DialogTitle>Document Verification - {rider.name}</DialogTitle>
                                <DialogDescription>
                                  Review and verify rider documents from Supabase Storage
                                </DialogDescription>
                              </DialogHeader>
                              
                              <div className="space-y-4">
                                {/* Document List */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <Card className="p-4">
                                    <div className="flex items-start gap-3">
                                      <FileText className="size-8 text-[#3B82F6]" />
                                      <div className="flex-1">
                                        <p className="font-medium mb-1">Driving License</p>
                                        <p className="text-sm text-gray-500 mb-2">DL-{rider.id}.pdf</p>
                                        <div className="flex gap-2">
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Eye className="size-4" />
                                            Preview
                                          </Button>
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Download className="size-4" />
                                            Download
                                          </Button>
                                        </div>
                                      </div>
                                    </div>
                                  </Card>

                                  <Card className="p-4">
                                    <div className="flex items-start gap-3">
                                      <FileText className="size-8 text-[#3B82F6]" />
                                      <div className="flex-1">
                                        <p className="font-medium mb-1">Aadhaar Card</p>
                                        <p className="text-sm text-gray-500 mb-2">AADHAAR-{rider.id}.pdf</p>
                                        <div className="flex gap-2">
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Eye className="size-4" />
                                            Preview
                                          </Button>
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Download className="size-4" />
                                            Download
                                          </Button>
                                        </div>
                                      </div>
                                    </div>
                                  </Card>

                                  <Card className="p-4">
                                    <div className="flex items-start gap-3">
                                      <FileText className="size-8 text-[#3B82F6]" />
                                      <div className="flex-1">
                                        <p className="font-medium mb-1">Vehicle RC</p>
                                        <p className="text-sm text-gray-500 mb-2">RC-{rider.id}.pdf</p>
                                        <div className="flex gap-2">
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Eye className="size-4" />
                                            Preview
                                          </Button>
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Download className="size-4" />
                                            Download
                                          </Button>
                                        </div>
                                      </div>
                                    </div>
                                  </Card>

                                  <Card className="p-4">
                                    <div className="flex items-start gap-3">
                                      <FileText className="size-8 text-[#3B82F6]" />
                                      <div className="flex-1">
                                        <p className="font-medium mb-1">Police Verification</p>
                                        <p className="text-sm text-gray-500 mb-2">PV-{rider.id}.pdf</p>
                                        <div className="flex gap-2">
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Eye className="size-4" />
                                            Preview
                                          </Button>
                                          <Button size="sm" variant="outline" className="gap-2">
                                            <Download className="size-4" />
                                            Download
                                          </Button>
                                        </div>
                                      </div>
                                    </div>
                                  </Card>
                                </div>

                                {/* Verification Actions */}
                                <div className="flex justify-end gap-3 pt-4 border-t">
                                  <Button variant="outline" className="gap-2 text-[#EF4444]">
                                    <XCircle className="size-4" />
                                    Reject Documents
                                  </Button>
                                  <Button className="gap-2 bg-[#10B981] hover:bg-[#059669]">
                                    <CheckCircle className="size-4" />
                                    Approve & Verify
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            rider.status === 'Approved'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          }
                        >
                          {rider.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {rider.status === 'Pending Approval' && (
                            <>
                              <Button variant="ghost" size="sm" className="text-[#10B981]" title="Approve">
                                <UserCheck className="size-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-[#EF4444]" title="Reject">
                                <XCircle className="size-4" />
                              </Button>
                            </>
                          )}
                          <Button variant="ghost" size="sm">
                            <Eye className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Hospitals Tab */}
        <TabsContent value="hospitals" className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                <Input placeholder="Search hospitals..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Verification" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Hospital ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>License Number</TableHead>
                    <TableHead>Inventory</TableHead>
                    <TableHead>Documents</TableHead>
                    <TableHead>Verification</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {hospitalsData.map((hospital) => (
                    <TableRow key={hospital.id}>
                      <TableCell className="font-medium">{hospital.id}</TableCell>
                      <TableCell>{hospital.name}</TableCell>
                      <TableCell className="font-mono text-sm">{hospital.license}</TableCell>
                      <TableCell>
                        {hospital.inventoryConnected ? (
                          <Badge variant="outline" className="bg-[#F0FDF4] text-[#10B981] border-[#10B981]">
                            Connected
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-100 text-gray-600 border-gray-400">
                            Not Connected
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {hospital.documentsVerified ? (
                          <Badge variant="outline" className="bg-[#F0FDF4] text-[#10B981] border-[#10B981]">
                            <CheckCircle className="size-3 mr-1" />
                            Verified
                          </Badge>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2 text-[#F97316] border-[#F97316]"
                          >
                            <FileText className="size-4" />
                            Review
                          </Button>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            hospital.verification === 'Verified'
                              ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                              : 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          }
                        >
                          {hospital.verification}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {hospital.verification === 'Pending' && (
                            <>
                              <Button variant="ghost" size="sm" className="text-[#10B981]" title="Approve">
                                <CheckCircle className="size-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-[#EF4444]" title="Suspend">
                                <Ban className="size-4" />
                              </Button>
                            </>
                          )}
                          <Button variant="ghost" size="sm">
                            <Eye className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
