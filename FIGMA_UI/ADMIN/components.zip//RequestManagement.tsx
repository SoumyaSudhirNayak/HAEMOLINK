import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Search, Filter, Eye, AlertTriangle, CheckCircle, Clock, TruckIcon } from 'lucide-react';

const requestsData = [
  { 
    id: 'REQ-8901', 
    patient: 'Rajesh Kumar', 
    bloodGroup: 'O-', 
    urgency: 'Critical', 
    component: 'Whole Blood',
    acceptedBy: 'AIIMS Delhi', 
    rider: 'Suresh Kumar',
    deliveryStatus: 'In Transit',
    requestedAt: '2026-01-09 14:23',
    region: 'North Delhi'
  },
  { 
    id: 'REQ-8902', 
    patient: 'Priya Sharma', 
    bloodGroup: 'A+', 
    urgency: 'High', 
    component: 'Platelets',
    acceptedBy: 'Lilavati Hospital', 
    rider: 'Mohammed Ali',
    deliveryStatus: 'Delivered',
    requestedAt: '2026-01-09 13:45',
    region: 'South Mumbai'
  },
  { 
    id: 'REQ-8903', 
    patient: 'Amit Patel', 
    bloodGroup: 'B+', 
    urgency: 'Critical', 
    component: 'RBC',
    acceptedBy: 'Apollo Hospitals', 
    rider: 'Pending Assignment',
    deliveryStatus: 'Pending Pickup',
    requestedAt: '2026-01-09 14:56',
    region: 'West Bangalore'
  },
  { 
    id: 'REQ-8904', 
    patient: 'Sneha Reddy', 
    bloodGroup: 'AB-', 
    urgency: 'Medium', 
    component: 'Plasma',
    acceptedBy: 'Max Healthcare', 
    rider: 'Ravi Shankar',
    deliveryStatus: 'In Transit',
    requestedAt: '2026-01-09 12:15',
    region: 'Central Chennai'
  },
  { 
    id: 'REQ-8905', 
    patient: 'Vikram Singh', 
    bloodGroup: 'O+', 
    urgency: 'Low', 
    component: 'Whole Blood',
    acceptedBy: 'Fortis Hospital', 
    rider: 'Deepak Yadav',
    deliveryStatus: 'Scheduled',
    requestedAt: '2026-01-09 11:30',
    region: 'East Kolkata'
  },
];

export function RequestManagement() {
  return (
    <div className="space-y-6 mt-16">
      {/* Page Header */}
      <div>
        <h2 className="font-semibold text-gray-900 mb-1">System-Wide Request Management</h2>
        <p className="text-sm text-gray-500">Unified view of all blood requests across the ecosystem</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 border-l-4 border-l-[#EF4444]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#FEF2F2] flex items-center justify-center">
              <AlertTriangle className="size-5 text-[#EF4444]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">12</p>
              <p className="text-sm text-gray-500">Critical Requests</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#F97316]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#FFF7ED] flex items-center justify-center">
              <Clock className="size-5 text-[#F97316]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">28</p>
              <p className="text-sm text-gray-500">Pending Pickup</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#3B82F6]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#EFF6FF] flex items-center justify-center">
              <TruckIcon className="size-5 text-[#3B82F6]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">45</p>
              <p className="text-sm text-gray-500">In Transit</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#10B981]">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-[#F0FDF4] flex items-center justify-center">
              <CheckCircle className="size-5 text-[#10B981]" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">189</p>
              <p className="text-sm text-gray-500">Delivered Today</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input placeholder="Search requests..." className="pl-10" />
          </div>
          
          <Select defaultValue="all-urgency">
            <SelectTrigger>
              <SelectValue placeholder="Urgency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-urgency">All Urgency</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="all-regions">
            <SelectTrigger>
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-regions">All Regions</SelectItem>
              <SelectItem value="north">North</SelectItem>
              <SelectItem value="south">South</SelectItem>
              <SelectItem value="east">East</SelectItem>
              <SelectItem value="west">West</SelectItem>
              <SelectItem value="central">Central</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="all-components">
            <SelectTrigger>
              <SelectValue placeholder="Component" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-components">All Components</SelectItem>
              <SelectItem value="whole-blood">Whole Blood</SelectItem>
              <SelectItem value="rbc">RBC</SelectItem>
              <SelectItem value="platelets">Platelets</SelectItem>
              <SelectItem value="plasma">Plasma</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Unified Request Table */}
      <Card className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">All Blood Requests</h3>
            <p className="text-sm text-gray-500">🔴 Live updates from all registered hospitals</p>
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="size-4" />
            Advanced Filters
          </Button>
        </div>

        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Request ID</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Blood Group</TableHead>
                <TableHead>Component</TableHead>
                <TableHead>Urgency</TableHead>
                <TableHead>Accepted By</TableHead>
                <TableHead>Rider</TableHead>
                <TableHead>Delivery Status</TableHead>
                <TableHead>Region</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {requestsData.map((request) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium font-mono text-sm">{request.id}</TableCell>
                  <TableCell>{request.patient}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]">
                      {request.bloodGroup}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{request.component}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        request.urgency === 'Critical'
                          ? 'bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]'
                          : request.urgency === 'High'
                          ? 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          : request.urgency === 'Medium'
                          ? 'bg-[#FFFBEB] text-yellow-600 border-yellow-500'
                          : 'bg-gray-100 text-gray-600 border-gray-400'
                      }
                    >
                      {request.urgency}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{request.acceptedBy}</TableCell>
                  <TableCell className="text-sm">{request.rider}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        request.deliveryStatus === 'Delivered'
                          ? 'bg-[#F0FDF4] text-[#10B981] border-[#10B981]'
                          : request.deliveryStatus === 'In Transit'
                          ? 'bg-[#EFF6FF] text-[#3B82F6] border-[#3B82F6]'
                          : request.deliveryStatus === 'Pending Pickup'
                          ? 'bg-[#FFF7ED] text-[#F97316] border-[#F97316]'
                          : 'bg-gray-100 text-gray-600 border-gray-400'
                      }
                    >
                      {request.deliveryStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{request.region}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      <Eye className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Manual Override Panel */}
      <Card className="p-6 border-[#8B5CF6]">
        <div className="mb-4">
          <h3 className="font-semibold text-gray-900 mb-1">Manual Override Panel</h3>
          <p className="text-sm text-gray-500">Admin controls for exceptional cases</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="p-4 bg-[#F5F3FF]">
            <h4 className="font-medium mb-3">Emergency Priority Override</h4>
            <div className="space-y-3">
              <Input placeholder="Request ID" />
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Set Priority Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical - Immediate</SelectItem>
                  <SelectItem value="high">High Priority</SelectItem>
                  <SelectItem value="medium">Medium Priority</SelectItem>
                </SelectContent>
              </Select>
              <Button className="w-full bg-[#8B5CF6] hover:bg-[#7C3AED]">
                Apply Override
              </Button>
            </div>
          </Card>

          <Card className="p-4 bg-[#EFF6FF]">
            <h4 className="font-medium mb-3">Manual Rider Assignment</h4>
            <div className="space-y-3">
              <Input placeholder="Request ID" />
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select Rider" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rider1">Suresh Kumar (North Delhi)</SelectItem>
                  <SelectItem value="rider2">Mohammed Ali (South Mumbai)</SelectItem>
                  <SelectItem value="rider3">Ravi Shankar (East Kolkata)</SelectItem>
                </SelectContent>
              </Select>
              <Button className="w-full bg-[#3B82F6] hover:bg-[#2563EB]">
                Assign Rider
              </Button>
            </div>
          </Card>
        </div>
      </Card>
    </div>
  );
}
